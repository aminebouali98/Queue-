package com.example.queuetv;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.content.Intent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import android.content.Context;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private static final String PREFS = "queue_tv_prefs";
    private static final String KEY_NUMBER = "number";
    private static final String KEY_PAD = "leading_zeroes";
    private static final String KEY_BACKGROUND_URI = "background_uri";
    private static final String KEY_BACKGROUND_FILE = "background_file";
    private static final String KEY_NUMBER_COLOR = "number_color";
    private static final int[] NUMBER_COLORS = { Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE };
    private static final String[] NUMBER_COLOR_NAMES = { "Black", "White", "Red", "Green", "Blue" };
    private static final int PICK_BACKGROUND = 412;
    private int number = 1;
    private boolean leadingZeroes = true;
    private int numberColor = Color.WHITE;
    private TextView numberView, modeView, hintView;
    private FrameLayout screen;
    private ImageView backgroundView;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        int uiFlags = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
        if (android.os.Build.VERSION.SDK_INT >= 19) uiFlags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        getWindow().getDecorView().setSystemUiVisibility(uiFlags);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        number = Math.max(0, prefs.getInt(KEY_NUMBER, 1));
        leadingZeroes = prefs.getBoolean(KEY_PAD, true);
        numberColor = prefs.getInt(KEY_NUMBER_COLOR, Color.WHITE);
        buildUi();
        restoreBackground();
        updateDisplay();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        screen = new FrameLayout(this);
        backgroundView = new ImageView(this);
        backgroundView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backgroundView.setVisibility(View.GONE);
        screen.addView(backgroundView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(14), dp(28), dp(14));
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("NOW SERVING");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        numberView = new TextView(this);
        numberView.setTextColor(Color.WHITE);
        numberView.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        numberView.setGravity(Gravity.CENTER);
        numberView.setTextSize(160);
        numberView.setSingleLine(true);
        root.addView(numberView, new LinearLayout.LayoutParams(-1, 0, 1f));

        modeView = new TextView(this);
        modeView.setTextColor(Color.LTGRAY);
        modeView.setTextSize(14);
        modeView.setGravity(Gravity.CENTER);
        root.addView(modeView, new LinearLayout.LayoutParams(-1, dp(24)));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        addButton(controls, "−  PREVIOUS", v -> change(-1));
        addButton(controls, "+  NEXT", v -> change(1));
        addButton(controls, "ENTER NUMBER", v -> showNumberDialog());
        addButton(controls, "FORMAT: 025 / 25", v -> toggleFormat());
        addButton(controls, "SET PNG BACKGROUND", v -> chooseBackground());
        addButton(controls, "NUMBER COLOR", v -> showColorDialog());
        root.addView(controls, new LinearLayout.LayoutParams(-1, dp(58)));

        hintView = new TextView(this);
        hintView.setText("UP/DOWN: change • OK: enter number • MENU: format • B: background • C: number color");
        hintView.setTextColor(Color.GRAY);
        hintView.setTextSize(12);
        hintView.setGravity(Gravity.CENTER);
        root.addView(hintView, new LinearLayout.LayoutParams(-1, dp(28)));
        root.setBackgroundColor(Color.TRANSPARENT);
        screen.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(screen);
        // Put initial focus on the main number so D-pad commands work immediately.
        numberView.setFocusable(true);
        numberView.setFocusableInTouchMode(true);
        numberView.requestFocus();
    }

    private void addButton(LinearLayout row, String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        b.setFocusable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        row.addView(b, lp);
    }

    private void updateDisplay() {
        String shown = leadingZeroes ? String.format(java.util.Locale.US, "%03d", number) : String.valueOf(number);
        numberView.setText(shown);
        numberView.setTextColor(numberColor);
        modeView.setText(leadingZeroes ? "Three-digit format (001–999+)" : "Normal number format");
        prefs.edit().putInt(KEY_NUMBER, number).putBoolean(KEY_PAD, leadingZeroes).putInt(KEY_NUMBER_COLOR, numberColor).apply();
    }

    private void change(int delta) {
        number = Math.max(0, number + delta);
        updateDisplay();
    }

    private void toggleFormat() {
        leadingZeroes = !leadingZeroes;
        updateDisplay();
        Toast.makeText(this, leadingZeroes ? "Format: 001" : "Format: 1", Toast.LENGTH_SHORT).show();
    }

    private void showNumberDialog() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setSingleLine(true);
        input.setText(String.valueOf(number));
        input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
            .setTitle("Enter queue number")
            .setMessage("Type any number, then choose Set.")
            .setView(input)
            .setPositiveButton("Set", (dialog, which) -> {
                try {
                    String value = input.getText().toString().trim();
                    if (!value.isEmpty()) number = Math.max(0, Integer.parseInt(value));
                    updateDisplay();
                } catch (NumberFormatException ex) {
                    Toast.makeText(this, "Please enter a valid whole number", Toast.LENGTH_SHORT).show();
                }
                numberView.requestFocus();
            })
            .setNegativeButton("Cancel", (dialog, which) -> numberView.requestFocus())
            .show();
    }


    private void showColorDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Queue number color")
            .setSingleChoiceItems(NUMBER_COLOR_NAMES, colorIndex(numberColor), (dialog, which) -> {
                numberColor = NUMBER_COLORS[which];
                updateDisplay();
                dialog.dismiss();
                numberView.requestFocus();
            })
            .setNegativeButton("Cancel", (dialog, which) -> numberView.requestFocus())
            .show();
    }

    private int colorIndex(int color) {
        for (int i = 0; i < NUMBER_COLORS.length; i++) if (NUMBER_COLORS[i] == color) return i;
        return 1;
    }

    private void chooseBackground() {
        Intent intent;
        if (android.os.Build.VERSION.SDK_INT >= 19) {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/png");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        } else {
            // ACTION_OPEN_DOCUMENT is unavailable on Android 4.0–4.3.
            intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/png");
        }
        try { startActivityForResult(Intent.createChooser(intent, "Choose PNG background"), PICK_BACKGROUND); }
        catch (Exception e) { Toast.makeText(this, "No file picker is available on this TV", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_BACKGROUND || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        InputStream input = null;
        OutputStream output = null;
        try {
            // Copy the chosen image into app-private storage so it remains available
            // after reboot even on Android versions without persistable URI permissions.
            input = getContentResolver().openInputStream(uri);
            if (input == null) throw new IOException("Unable to open image");
            File imageFile = new File(getFilesDir(), "queue_background.png");
            output = new FileOutputStream(imageFile);
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            output.flush();
            Bitmap bitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
            if (bitmap == null) throw new IOException("Invalid PNG image");
            prefs.edit().putString(KEY_BACKGROUND_FILE, imageFile.getAbsolutePath()).remove(KEY_BACKGROUND_URI).apply();
            backgroundView.setImageBitmap(bitmap);
            backgroundView.setVisibility(View.VISIBLE);
            Toast.makeText(this, "PNG background set", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't load that image. Please choose a PNG file.", Toast.LENGTH_LONG).show();
        } finally {
            try { if (input != null) input.close(); } catch (Exception ignored) {}
            try { if (output != null) output.close(); } catch (Exception ignored) {}
        }
        numberView.requestFocus();
    }

    private void restoreBackground() {
        String filePath = prefs.getString(KEY_BACKGROUND_FILE, null);
        if (filePath != null) {
            try {
                Bitmap bitmap = BitmapFactory.decodeFile(filePath);
                if (bitmap != null) {
                    backgroundView.setImageBitmap(bitmap);
                    backgroundView.setVisibility(View.VISIBLE);
                    return;
                }
            } catch (Exception ignored) {}
        }
        // Backward compatibility with projects that stored a URI.
        String saved = prefs.getString(KEY_BACKGROUND_URI, null);
        if (saved != null) {
            try { applyBackground(Uri.parse(saved)); }
            catch (Exception ignored) { prefs.edit().remove(KEY_BACKGROUND_URI).apply(); }
        }
    }

    private void applyBackground(Uri uri) throws Exception {
        InputStream input = null;
        try {
            input = getContentResolver().openInputStream(uri);
            if (input == null) throw new IOException("Unable to open image");
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            if (bitmap == null) throw new IOException("Invalid image");
            backgroundView.setImageBitmap(bitmap);
            backgroundView.setVisibility(View.VISIBLE);
        } finally {
            if (input != null) try { input.close(); } catch (Exception ignored) {}
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP: change(1); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: change(-1); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: change(1); return true;
            case KeyEvent.KEYCODE_DPAD_LEFT: change(-1); return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER: showNumberDialog(); return true;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_M: toggleFormat(); return true;
            case KeyEvent.KEYCODE_B: chooseBackground(); return true;
            case KeyEvent.KEYCODE_C: showColorDialog(); return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT: change(1); return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: change(-1); return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
