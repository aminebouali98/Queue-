# Queue TV — Android 10+

Queue TV is an offline queue-number display for Android TV, configured for **Android 10 (API 29) and newer**.

## Features
- Full-screen queue number display.
- Increase/decrease with the TV remote and enter a number directly.
- Choose padded (`025`) or normal (`25`) number format.
- Choose a PNG background.
- Choose number color: black, white, red, green, or blue.
- Remembers settings and works offline after installation.

## Build an APK using only a phone (free GitHub Actions)
This project includes `.github/workflows/build.yml`. GitHub's hosted runner builds the APK; you do not need a computer, Android Studio, or a credit card for this workflow, though GitHub account limits and policies apply.

1. Download this ZIP and extract it on your phone.
2. Open GitHub in your browser and sign in or create a free account: https://github.com
3. Create a **public** repository named `QueueTV` (public repositories can use standard GitHub-hosted Actions without consuming private-repository minutes).
4. Upload the **contents of this `QueueTV` folder** to the repository's top level. Make sure the `.github` folder is included. If your phone's file picker hides dot-folders, use GitHub's website to create `.github/workflows/build.yml` and paste in the workflow from the downloaded project.
5. Open the repository's **Actions** tab. If asked, enable workflows.
6. Choose **Build Queue TV APK** and tap **Run workflow**. Alternatively, uploading the files to the `main` branch should start a build automatically.
7. When the run finishes with a green check, open it and find **Artifacts** near the bottom. Download `QueueTV-Android10-APK`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
9. Transfer/open `app-debug.apk` on your Android TV and allow installation from that source if Android asks.

If the build fails, open the failed run and read the first red error in the build log; the APK will not be available until the workflow succeeds.

## Android Studio build
Open this folder as a project in Android Studio and build the `app` debug APK. The APK path is `app/build/outputs/apk/debug/app-debug.apk`.

Note: this ZIP contains source code and a cloud-build workflow, not a precompiled APK. The project has not been tested on a physical Android TV.


## Android version and hidden settings

This version requires Android 10 (API 29) or newer. The queue number is shown on screen by itself. Press and hold the TV remote's OK/Enter button for about 0.7 seconds to reveal the settings controls (number entry, number format, PNG background, and number color). Press and hold OK/Enter again, or press Back, to hide the settings.
